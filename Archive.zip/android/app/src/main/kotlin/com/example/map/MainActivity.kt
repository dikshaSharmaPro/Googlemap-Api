package com.example.map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
