import 'package:get/get.dart';

class ProfileController extends GetxController {
  RxBool isTNCSelected = false.obs;
}
