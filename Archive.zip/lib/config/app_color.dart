import 'dart:ui';

class AppColor {
  static const loginBgImageColor = Color(0xFFF3F3F3);
}
